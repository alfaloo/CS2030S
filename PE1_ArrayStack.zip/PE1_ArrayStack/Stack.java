/**
 * CS2030S PE1 Question 2
 * AY21/22 Semester 2
 *
 * @author A0000000X
 */

interface Stack<T> {
  public T pop();

  public void push(T item);

  public int getStackSize();
}
