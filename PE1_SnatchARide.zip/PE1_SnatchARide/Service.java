interface Service {
  public int computeFare(Request request);

  public String toString();
}
