/**
 * CS2030S Lab 5
 * AY22/23 Semester 2
 *
 * @author Zhiyang Lu (Lab 14H)
 */

package cs2030s.fp;

public interface Producer<T> {

  public T produce();

}
