# CS2030S AY22/23 Sem 2 Lab 3
## Feedback for alfaloo
Your submission follows the CS2030S Java style guide. :+1:

The tutor has marked your code. You can find [the comments from your tutor here](https://www.github.com/nus-cs2030s-2223-s2/lab3-alfaloo/commit/04d187a4081218e587259878f6e1276c801d7dd9).
### Summary

| Component | Marks |
|-----------|-------|
| Style | 2 |
| Queue/Array/Counters | 7 |
| Correctness | 3 |
| Design | 4 |
| **TOTAL** | 16 |
