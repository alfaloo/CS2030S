# CS2030S AY22/23 Sem 2 Lab 6
## Feedback for alfaloo
Your submission follows the CS2030S Java style guide. :+1:

The tutor has marked your code. You can find [the comments from your tutor here](https://www.github.com/nus-cs2030s-2223-s2/lab6-alfaloo/commit/37d175191588b96a744a89acd761a242a9d30ead).
### Summary

| Component | Marks |
|-----------|-------|
| Style | 0 |
| Marks | 12 |
| **TOTAL** | 12 |
