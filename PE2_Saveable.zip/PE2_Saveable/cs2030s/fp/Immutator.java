package cs2030s.fp;

public interface Immutator<R, P> {
    R invoke (P param);
}
