# CS2030S AY22/23 Sem 2 Lab 2
## Feedback for alfaloo
Your submission follows the CS2030S Java style guide. :+1:

The tutor has marked your code. You can find [the comments from your tutor here](https://www.github.com/nus-cs2030s-2223-s2/lab2-alfaloo/commit/d0490d12c2eb7710f2da81644012075c6a90e60c).
### Summary

| Component | Marks |
|-----------|-------|
| Style | 2 |
| Correctness | 2 |
| Design | 7 |
| **TOTAL** | 11 |
