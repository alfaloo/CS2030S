# CS2030S AY22/23 Sem 2 Lab 8
## Feedback for alfaloo
Your submission follows the CS2030S Java style guide. :+1:

The tutor has marked your code. You can find [the comments from your tutor here](https://www.github.com/nus-cs2030s-2223-s2/lab8-alfaloo/commit/baecd8f42324c9adb820bc21ee44938c03a0f051).
### Summary

| Component | Marks |
|-----------|-------|
| Style | 0 |
| Correctness/Design | 12 |
| **TOTAL** | 12 |
