# CS2030S AY22/23 Sem 2 Lab 4
## Feedback for alfaloo
Your submission follows the CS2030S Java style guide. :+1:

The tutor has marked your code. You can find [the comments from your tutor here](https://www.github.com/nus-cs2030s-2223-s2/lab4-alfaloo/commit/c35ec97c62177327647b712cb1937553886b5adf).
### Summary

| Component | Marks |
|-----------|-------|
| Style | 2 |
| Marks | 10 |
| **TOTAL** | 12 |
