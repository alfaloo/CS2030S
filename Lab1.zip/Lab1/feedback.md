# CS2030S AY22/23 Sem 2 Lab 1
## Feedback for alfaloo

The tutor has marked your code. You can find [the comments from your tutor here](https://www.github.com/nus-cs2030s-2223-s2/lab1-alfaloo/commit/68f0180a79327eed6ff2631c8101115eccfe3edb).
### Summary

| Component | Marks |
|-----------|-------|
| Correctness | 3 |
| Design | 10 |
| **TOTAL** | 13 |
