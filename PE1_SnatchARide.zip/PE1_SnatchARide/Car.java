interface Car {
  public String toString();

  public int getTime();
}
